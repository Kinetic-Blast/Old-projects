import static org.junit.Assert.*;

import org.junit.Test;

public class CardsTest {
	
	public Cards card1 = new Cards("card1front", "card1Back");
	public Cards card2 = new Cards("card2front", "card2Back");
	public Cards card3 = new Cards("card3front", "card3Back");
	public Cards card4 = new Cards("card4front", "card4Back");
	
	boolean x=true;

	
	@Test
	public void testGetQuestion() {
		if(card1.getQuestion() == "card1front") {
			if(card2.getQuestion() == "card2front") {
				if(card3.getQuestion() == "card3front") {
					if(card4.getQuestion() == "card4front") {
						assertTrue(x);}}}}
		else { fail("all cards did not retrive the correct string");}}

	@Test
	public void testGetAwnser() {
		if(card1.getAwnser() == "card1Back") {
			if(card2.getAwnser() == "card2Back") {
				if(card3.getAwnser() == "card3Back") {
					if(card4.getAwnser() == "card4Back") {
						assertTrue(x);}}}}
		else { fail("all cards did not retrive the correct string");}}

	@Test
	public void testSetQuestion() {
		card1.setQuestion("card1new");
		card2.setQuestion("card2new");
		card3.setQuestion("card3new");
		card4.setQuestion("card4new");
		
		if(card1.getQuestion() == "card1new") {
			if(card2.getQuestion() == "card2new") {
				if(card3.getQuestion() == "card3new") {
					if(card4.getQuestion() == "card4new") {
						assertTrue(x);}}}}
		else {fail("all cards did not retrive the correct string");}}

	@Test
	public void testSetAwnser() {
		card1.setAwnser("card1newA");
		card2.setAwnser("card2newA");
		card3.setAwnser("card3newA");
		card4.setAwnser("card4newA");
		
		if(card1.getAwnser() == "card1newA") {
			if(card2.getAwnser() == "card2newA") {
				if(card3.getAwnser() == "card3newA") {
					if(card4.getAwnser() == "card4newA") {
						assertTrue(x);}}}}
		else {fail("all cards did not retrive the correct string");}}

	@Test
	public void testToString() {
		System.out.println(card1.toString());
		System.out.println(card2.toString());
		System.out.println(card3.toString());
		System.out.println(card4.toString());
		assertTrue(x);
	}

}
