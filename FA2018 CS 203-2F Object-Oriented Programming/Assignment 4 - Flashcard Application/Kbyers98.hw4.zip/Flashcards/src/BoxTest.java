import static org.junit.Assert.*;

import org.junit.Test;

public class BoxTest {
	
	boolean x = true;
	
	public Cards card1 = new Cards("card1front", "card1Back");
	public Cards card2 = new Cards("card2front", "card2Back");
	public Cards card3 = new Cards("card3front", "card3Back");
	public Cards card4 = new Cards("card4front", "card4Back");
	
	public Box box1 = new Box ("Box 1");//should be box #0
	public Box box2 = new Box ("Box 2");// should be box #1

	@Test
	public void testGetBoxName() {
		if(box1.getBoxName() == "Box 1") {
			if (box2.getBoxName() == "Box 2") {
				assertTrue(x);}}
		else {fail("Did not return the correct names for the boxes");}}

	@Test
	public void testSetBoxName() {
		box1.setBoxName("box1 new");
		box2.setBoxName("box2 new");
		
		if(box1.getBoxName() == "box1 new") {
			if (box2.getBoxName() == "box2 new") {
				assertTrue(x);}}
		else {fail("Did not return the correct names for the boxes");}}

	@Test
	public void testGetBoxNumber() {
		if(box1.getBoxNumber() == 0) {
			if (box2.getBoxNumber() == 1) {
				assertTrue(x);}}
		else {fail("Did not return the correct numbers for the boxes");}}

	@Test
	public void testAddToBox() {
		box1.addToBox(card1);
		box2.addToBox(card2);
		box1.addToBox(card3);
		
		if (box1.contains(card1)){
			if(box2.contains(card2)) {
				if (box1.contains(card3)) {
					if (box1.contains(card4)) {
						fail("card4 was not added");}
					else {assertTrue(x);}}}}
		else{fail("test was not able to find objects in the boxes");}}

	@Test
	public void testRfromBox() {
		box1.addToBox(card1);
		box1.addToBox(card2);
		box1.addToBox(card3);
		box1.addToBox(card4);
		
		box2.addToBox(card3);
		box2.addToBox(card4);
		
		box1.rfromBox(card2);
		box1.rfromBox(card4);
		box2.rfromBox(card3);
		
		if (box1.doesnotcontain(card2)){
			if (box2.doesnotcontain(card3)) {
				if(box1.doesnotcontain(card4)) {
					if(box1.contains(card2)) {
						fail("card2 should not be in box1");}
					else {assertTrue(x);}}}}
		else {fail("a card was detected that should have been removed");}}

	@Test
	public void testToString() {
		box1.addToBox(card1);
		box1.addToBox(card2);
		box1.addToBox(card3);
		box1.addToBox(card4);
		
		System.out.println(box1.toString());
		System.out.println(box2.toString());
		
		assertTrue(x);}}
