/**
 * Flash Card Interface
 * @author Baylee Byers
 * @version 1.0 29 September 2018
 *
 */
public class Cards {
	
	private String Side1;
	private String Side2;
	
	/**
	 * Constructs the flash cards using two strings for side one and two
	 * @param question -String side one of the card
	 * @param awnser - String side two of the card
	 */
	public Cards(String question, String awnser) {
		this.Side1 = question;
		this.Side2 = awnser;}
	
	/**
	 * gets the variable on side one of the card and returns it
	 * @return Side1 - String value on the first side of the note card (also know as the question)
	 */
	public String getQuestion() {
		return Side1;}
	
	/**
	 * gets the variable side two of the card and returns it 
	 * @return Side2 - String value on the second side of the note card (also know as the answer)
	 */
	public String getAwnser() {
		return Side2;}
	
	/**
	 * replaces side 1 or the question side to what ever is specified
	 * @param arg0 - String that the side one will change to
	 */
	public void setQuestion(String arg0) {
		this.Side1 = arg0;}
	
	/**
	 * replaces side 2 or the answer side to what ever is specified
	 * @param arg0- String that the side one will change to
	 */
	public void setAwnser(String arg0) {
		this.Side2 = arg0;}
	
	/**
	 * toString method makes the object into a string object
	 * @return String- string
	 */
	public String toString() {
		return ("Question: " + this.getQuestion() + " Awnser: "+ this.getAwnser());}

}
