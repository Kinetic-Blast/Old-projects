/**
 * Java Fraction Calculator
 * Allows Fractions to be:Created,Added,Subtracted, Multiplied, Divided,Greatest common denominators,Remainders,Quotients, its Double Value and make
 * it to a String
 * @author Baylee Byers
 * @version 1.0 16 September 2018
 */

public class Fraction {
	/**
	 * Java Fraction Calculator
	 * Allows Fractions to be:Created,Added,Subtracted, Multiplied, Divided,Greatest common denominators,Remainders,Quotients, its Double Value and make
	 * it to a String
	 * @author Baylee Byers
	 * @version 1.0 16 September 2018
	 */
	
	private double num;
	private double den;
	
	
	/**
	 * Constructs the fractions using two given doubles. Will not create a fraction with the denominator of zero and will replace it with a 1
	 * example: fraction 2/0 will be created as 2/1 
	 * @param num_var double
	 * @param den_var double
	 */
	//used to  the fractions
	public Fraction(double num_var, double den_var){
		this.num = num_var;
		if (den_var==0) {
			System.out.println("invaild Fraction setting "+ num_var+"/"+den_var +" denominator to 1 \n");
			this.den = 1;
			return;}
		this.den = den_var;}
	

	/**
	 * used to calculate the gcd when given two doubles and returns it
	 * 
	 * @param temptop-double
	 * @param tempbottom -double
	 * 
	 */
	//used to calculate the gcd when given two doubles and returns it
	public static double gcd(double temptop, double tempbottom){
	    if(temptop % tempbottom == 0) {return tempbottom;}
	    else{return gcd(tempbottom, temptop % tempbottom);}}

	/**
	 * to string method for fraction class
	 */
	//to string
	public String toString() {
		System.out.println("string output: "+this.num+"/"+this.den);
		return null;}

	/**
	 * Adds the to giving fractions then finds the GCD to reduce the fraction into a basic from and prints a output string does also return the added
	 * factions in a reduced new fraction state e.x of use Fraction.add(otherFraction);
	 * 
	 * @param otherFraction Fraction
	 * 
	 */
	
	//adds two fractions
	public Fraction add(Fraction otherFraction) {
		
//set the variables of the fractions to doubles
		double fn = this.num;
		double ofn= otherFraction.num; 
		double fd= this.den;
		double ofd= otherFraction.den;
		
//adds fractions
		double temptop =((fn*ofd)+(ofn*fd));
		double tempbottom = (fd*ofd);
		
//Calls gcd to reduce and create the reduced fraction and returns it
		Fraction temp = new Fraction (temptop/gcd(temptop,tempbottom),tempbottom/gcd(temptop,tempbottom));
		System.out.println(this.num +"/"+ this.den +" + "+ otherFraction.num +"/"+ otherFraction.den +" = "+ temp.num + "/"+ temp.den);
		return temp;}

	
	/**
	 * Subtracts the two given fractions and reduces it using the GCD example of use prints a output string does also return the
	 * factions in a reduced new fraction state e.x. Fraction.Sub(otherFraction);
	 * @param otherFraction Fraction
	 */
	//Subtracts two fractions
	public Fraction Sub(Fraction otherFraction) {
		
//set the variables of the fractions to doubles
		double fn = this.num;
		double ofn= otherFraction.num;
		double fd= this.den;
		double ofd= otherFraction.den;
				
//subtracts fractions
		double temptop =((fn*ofd)-(ofn*fd));
		double tempbottom = (fd*ofd);
				
//Calls gcd to reduce and create the reduced fraction
		Fraction temp = new Fraction (temptop/gcd(temptop,tempbottom),tempbottom/gcd(temptop,tempbottom));
		
//basic to string to print out the problem / returns the values
		System.out.println(this.num +"/"+ this.den +" - "+ otherFraction.num +"/"+ otherFraction.den +" = "+ temp.num + "/"+ temp.den);
		return temp;}

	
	/**
	 * Multiples the to giving fractions then finds the GCD to reduce the fraction into a basic from and prints a output string does also return the Multiplied 
	 * factions in a reduced new fraction state e.x of use Fraction.mul(otherFraction);
	 *
	 * @param otherFraction Fraction 
	 * 
	 */
	//Multiply fractions
	public Fraction mul(Fraction otherFraction) {
		
//sets the variables to doubles
		double fn = this.num;
		double ofn= otherFraction.num;
		double fd= this.den;
		double ofd= otherFraction.den;
		
//Multiples the fractions
		double temptop = (fn*ofn);
		double tempbottom = (fd*ofd);
		
//Calls gcd to reduce and create the reduced fraction and returns it
		Fraction temp = new Fraction (temptop/gcd(temptop,tempbottom),tempbottom/gcd(temptop,tempbottom));
		System.out.println(this.num +"/"+ this.den +" * "+ otherFraction.num +"/"+ otherFraction.den +" = "+ temp.num + "/"+ temp.den);
		return temp;}
	
	/**
	 * divides the to giving fractions then finds the GCD to reduce the fraction into a basic from and prints a output string does also return the divided 
	 * factions in a reduced new fraction state e.x of use Fraction.div(otherFraction);
	 * 
	 * @param otherFraction Fraction
	 */
	//Divide fractions
	public Fraction div(Fraction otherFraction) {
			
//sets the variables to doubles
		double fn = this.num;
		double ofn= otherFraction.num;
		double fd= this.den;
		double ofd= otherFraction.den;
			
//Divides the fractions
		double temptop = (fn*ofd);
		double tempbottom = (fd*ofn);
			
//Calls gcd to reduce and create the reduced fraction and returns it
		Fraction temp = new Fraction (temptop/gcd(temptop,tempbottom),tempbottom/gcd(temptop,tempbottom));
		System.out.println(this.num +"/"+ this.den +" * "+ otherFraction.num +"/"+ otherFraction.den +" = "+ temp.num + "/"+ temp.den);
		return temp;}

	/**
	 * Finds the quotient of the given function e.x. Fraction.getQuotient();
	 */
	//Gets the Quotient
	public double getQuotient() {
		double temp;
		temp = (this.num % this.den);
		
		System.out.println(temp+"/"+this.den);
		return temp;}
	
	
	/**
	 * Finds the float value of the given function e.x. Fraction.getRemainder();
	 */
	//gets the remainder
	public double getRemainder() {
		float temp =(float) (this.num/this.den);
		System.out.println(temp);
		return temp;}
	
	/**
	 * Finds the doubleValue of the given function e.x. Fraction.doubleValue();
	 *also accounts for odd fractions such as 1/0 and 42/1
	 */
	//gets a string rep. of the fraction
	public void doubleValue() {
		if (this.den == 0) {System.out.println("Infinty"); return;}
		if (this.den == 1) {System.out.println(this.num); return;}
		System.out.println(this.num +"/"+this.den);return;}}