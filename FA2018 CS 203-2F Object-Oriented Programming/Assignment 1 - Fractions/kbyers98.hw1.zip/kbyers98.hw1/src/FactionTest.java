
public class FactionTest {
	
	public static void main(String[]args) {
		Fraction name1 = new Fraction(4,5);
		Fraction name2 = new Fraction(2,0);
		Fraction name3 = new Fraction(13,2);
		Fraction name4 = new Fraction(1,2);
		
		System.out.println("Testing addion of first fraction....");
		name1.add(name2);
		name1.add(name3);
		name1.add(name4);
		System.out.print("\n");
		
		System.out.println("Testing subtraction of first fraction....");
		name1.Sub(name2);
		name1.Sub(name3);
		name1.Sub(name4);
		System.out.print("\n");
		
		System.out.println("Testing multipcation of first fraction....");
		name1.mul(name3);
		name1.mul(name2);
		name1.mul(name4);
		System.out.print("\n");
		
		System.out.println("Testing division of first fraction....");
		name1.div(name2);
		name1.div(name3);
		name1.div(name4);
		System.out.print("\n");
		
		System.out.println("Testing Quotient/ remainder / and double value of first fraction....");
		name1.getQuotient();
		name1.getRemainder();
		name1.doubleValue();
		System.out.print("\n");
		
		System.out.println("Testing to string of first fraction....");
		name1.toString();
		System.out.println("\n");
		
		System.out.println("______________________________________________________________________");
		
		
		System.out.println("Testing addion of second fraction....");
		name2.add(name1);
		name2.add(name3);
		name2.add(name4);
		System.out.print("\n");
		
		System.out.println("Testing subtraction of second fraction....");
		name2.Sub(name1);
		name2.Sub(name3);
		name2.Sub(name4);
		System.out.print("\n");
		
		System.out.println("Testing multipcation of second fraction....");
		name2.mul(name1);
		name2.mul(name3);
		name2.mul(name4);
		System.out.print("\n");
		
		System.out.println("Testing division of second fraction....");
		name2.div(name1);
		name2.div(name3);
		name2.div(name4);
		System.out.print("\n");
		
		System.out.println("Testing Quotient/ remainder / and double value of second fraction....");
		name2.getQuotient();
		name2.getRemainder();
		name2.doubleValue();
		System.out.print("\n");
		
		System.out.println("Testing to string of second fraction....");
		name2.toString();
		System.out.println("\n");
		
System.out.println("______________________________________________________________________");
		
		
		System.out.println("Testing addion of third fraction....");
		name3.add(name1);
		name3.add(name2);
		name3.add(name4);
		System.out.print("\n");
		
		System.out.println("Testing subtraction of third irfraction....");
		name3.Sub(name1);
		name3.Sub(name2);
		name3.Sub(name4);
		System.out.print("\n");
		
		System.out.println("Testing multipcation of third fraction....");
		name3.mul(name1);
		name3.mul(name2);
		name3.mul(name4);
		System.out.print("\n");
		
		System.out.println("Testing division of third fraction....");
		name3.div(name1);
		name3.div(name2);
		name3.div(name4);
		System.out.print("\n");
		
		System.out.println("Testing Quotient/ remainder / and double value of third fraction....");
		name3.getQuotient();
		name3.getRemainder();
		name3.doubleValue();
		System.out.print("\n");
		
		System.out.println("Testing to string of third fraction....");
		name3.toString();
		System.out.println("\n");
		
System.out.println("______________________________________________________________________");
		
		
		System.out.println("Testing addion of fouth fraction....");
		name4.add(name1);
		name4.add(name2);
		name4.add(name3);
		System.out.print("\n");
		
		System.out.println("Testing subtraction of forth irfraction....");
		name4.Sub(name1);
		name4.Sub(name2);
		name4.Sub(name3);
		System.out.print("\n");
		
		System.out.println("Testing multipcation of forth fraction....");
		name4.mul(name1);
		name4.mul(name2);
		name4.mul(name3);
		System.out.print("\n");
		
		System.out.println("Testing division of forth fraction....");
		name4.div(name1);
		name4.div(name2);
		name4.div(name3);
		System.out.print("\n");
		
		System.out.println("Testing Quotient/ remainder / and double value of forth fraction....");
		name4.getQuotient();
		name4.getRemainder();
		name4.doubleValue();
		System.out.print("\n");
		
		System.out.println("Testing to string of forth fraction....");
		name4.toString();
		System.out.println("\n");
		
		System.out.println("______________________________________________________________________");
		
		System.out.println("Testing addion of Its self with to sting....");
		name1.add(name1).toString();
		name2.add(name2).toString();
		name3.add(name3).toString();
		name4.add(name4).toString();
		System.out.print("\n");
		
		System.out.println("Testing subtraction of Its self with to sting....");
		name1.Sub(name1).toString();
		name2.Sub(name2).toString();
		name3.Sub(name3).toString();
		name4.Sub(name4).toString();
		System.out.print("\n");
		
		System.out.println("Testing multipcation of Its self with to sting....");
		name1.mul(name1).toString();
		name2.mul(name2).toString();
		name3.mul(name3).toString();
		name4.mul(name4).toString();
		System.out.print("\n");
		
		System.out.println("Testing division of Its self with to sting....");
		name1.div(name1).toString();
		name2.div(name2).toString();
		name3.div(name3).toString();
		name4.div(name4).toString();
		System.out.print("\n");}}
