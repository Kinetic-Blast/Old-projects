public class Library {
	public static double square_root(double value) {
		// added the square root function
		return Math.sqrt(value);
	}
}
