
import java.util.Scanner;

/**
 * This is a tester class to test the class Area. 
 * @author 
 *
 */
public class AreaTester {
	
	public static void main(String[] args){
		
		int check;
		boolean loop = true;
		
		Scanner in = new Scanner(System.in);
		/*
		 * This while loop asks you to choose a shape you want to calculate the aera and 
		 * after you choose a shape, you need to enter the dimensions.
		 */
		while (loop){
			
			System.out.println("\nSelect shape:\n 1: Circle \n 2: Triangle \n 3: Square \n 4: Rectangle \n 5: Exit");
			System.out.println("Enter your choice: ");
			check = in.nextInt();
		
			switch (check){
				/* Case for calculate Area of circle*/
				case 1:
					double r;
					System.out.println("Enter radius:");
					r = in.nextDouble();
					Area circle = new Area();
					double areaOfCircle = circle.circleArea(r);
					System.out.println("Your Area of Circle is: " + areaOfCircle);
					break;
					
				/* Case for calculate Area of Triangle*/	
				case 2:
					double r1;
					double r2;
					System.out.println("Enter Base:");
					r1 = in.nextDouble();
					System.out.println("Enter Hight:");
					r2=in.nextDouble();
					Area Triangle = new Area();
					double areaOfTriangle = Triangle.triangleArea(r1,r2);
					System.out.println("Your Area of The Triagle is: " + areaOfTriangle);
					break;
					
				/* Case for calculate Area of Square*/
				case 3:
					double r3;
					System.out.println("Enter side lenght:");
					r3 = in.nextDouble();
					Area Square = new Area();
					double areaOfSquare = Square.squareArea(r3);
					System.out.println("Your Area of Circle is: " + areaOfSquare);
					break;

					
				/* Case for calculate Area of Rectangle*/
				case 4:
					double r4;
					double r5;
					System.out.println("Enter Length:");
					r4 = in.nextDouble();
					System.out.println("Enter Width:");
					r5=in.nextDouble();
					Area Rectangle = new Area();
					double areaOfRectangle = Rectangle.rectangleArea(r4,r5);
					System.out.println("Your Area of The Triagle is: " + areaOfRectangle);
					break;
					
				/* Case for Exit from program*/
				case 5: 
					System.out.println("Bye have great day!!!");
					System.exit(0);
				
				/* Case for for user mistake*/
				default:
					System.out.println("Please select correct option");
			}
		}
		in.close();
	}
	

}
