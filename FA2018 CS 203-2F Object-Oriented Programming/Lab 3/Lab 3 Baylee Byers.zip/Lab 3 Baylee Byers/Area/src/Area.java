/**
 * This is class contains methods to compute aera of different shapes. 
 * @author 
 */
public class Area {

	
	/**
	 * This method computes the aera of a circle
	 * @param r
	 * @return the value of the aera of circle
	 */
	public  double circleArea (double r){
		
		return Math.PI * r * r;}
	
	/**
	 * This method computes the area of a triangle
	 * @param b, h
	 * @return the value of the area of triangle
	 */
	public double triangleArea (double r,double r2){		
		return ((r*r2)/2);}
	
	
	/**
	 * This method computes the area of a square
	 * @param r 
	 * @param l
	 * @return the value of the area of square
	 */
	public double squareArea (double r){
		return (r*r);}
	
	/**
	 * This method computes the area of a rectangle
	 * @param l, w
	 * @return the value of the area of rectangle
	 */
	public double rectangleArea (double r,double r2){
		return (r*r2);}}
