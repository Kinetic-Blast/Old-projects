import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MainPurchaseList {
	
	public static void main (String[] args) throws FileNotFoundException {
		
		ArrayList<BookStoreItem> list = new ArrayList<BookStoreItem>();
		double i = 0;
		
		Scanner in = new Scanner(new File("order.txt"));
		
		while (in.hasNextLine()) {
			
			String s2 = in.nextLine();
			String[] item = s2.split(" / ");
						
			if (item[0].equals("Book")) {
				list.add(new Book(item[1], Double.parseDouble(item[3]), item[2]));}
			
			else if(item[0].equals("Magazine")) {
				list.add(new Magazine(item[1],Double.parseDouble(item[3]),item[3]));}
			
			else if(item[0].equals("Movie")) {
				list.add(new Movie (item[1],Double.parseDouble(item[3]),item[2]));}}
		
		for (BookStoreItem temp2: list)
			i = i + temp2.getPrice();
		System.out.println("Total Price of all objects: $" + i);

		in.close();
	}
}
