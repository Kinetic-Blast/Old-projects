/**
 * The Magazine class is subclass represents a magazine. 
 */

public class Magazine extends BookStoreItem {
	
	private String date;
	
	public Magazine(String title, double price, String date) {
		super(title,price);
		this.date = date;}
	
	public String getDate() {
		return date;}
	
	public boolean equals(Object object) {
		if(!(object instanceof Magazine)) {return false;}
		Magazine Temp = (Magazine) object;
		return (this.getDate() == Temp.getDate() && this.getTitle() == Temp.getTitle() && this.getPrice() == Temp.getPrice());}
	
	public String toString() {
		return ("Date: "+ this.getDate() + " Title: "+ this.getTitle()+" Price: "+ this.getPrice());}}
