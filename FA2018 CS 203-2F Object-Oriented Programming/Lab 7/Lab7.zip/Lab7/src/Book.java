/**
 * The Book class is subclass represents a book. 
 */
public class Book extends BookStoreItem{
	
	private String author;
	
	public Book(String title, double price, String author) {
		super(title, price);
		this.author = author;}
	
	public String getAuthor() {
		return author;}
	
	public boolean equals(Object object) {
		if(!(object instanceof Book)) {return false;}
		Book Temp = (Book) object;
		return (this.getAuthor() == Temp.getAuthor() && this.getTitle() == Temp.getTitle() && this.getPrice() == Temp.getPrice());}

	public String toString() {
		return ("Author: "+ this.getAuthor() + " Title: "+ this.getTitle()+" Price: "+ this.getPrice());}}
