
/**
 * The ThreeDRectangle class represents a 3d rectangle with a method to compute the surface area.
 */
public class ThreeDRectangle extends Rectangle {
	private int wh;
	private int wl;
	private int ln;
	
	
	public ThreeDRectangle(int x, int y, int z) {
		wh = x;
		wl = z;
		ln = y;}
	
	
//	A public method for computing the Surface of 3D Rectangle
//	use superclass method getArea() to get the area
	public double getArea() {
		int area = 2*(wh+wl+ln);
		return area;}
	
	
	// YOUR CODE
	
	
}
