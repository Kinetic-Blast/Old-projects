import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MainSurfaceAreaTester {
	
	public static void main (String[] args) throws FileNotFoundException {
		
		boolean b = true;
		Scanner inS = new Scanner(System.in);
		
		while(b) {
			
			System.out.println("Please enter your command: ");
			
			String s1 = inS.nextLine();
			
			//when the input is import INPUT
			if (s1.equals("import INPUT")) {
				
				Scanner inF = new Scanner(new File("INPUT.txt"));
					while (inF.hasNextLine()) {
						String temp = inF.next();
						
						if(temp.equals("Rectangle")) {
							int w = inF.nextInt();
							int l = inF.nextInt();
							
							Rectangle tempR = new Rectangle(w,l);
							System.out.println("The Area of a Rectangle with the lenght of " + l + " and Width of " + w + " = "+ tempR.getArea());}
						
						if(temp.equals("ThreeDRectangle")) {
							int w = inF.nextInt();
							int l = inF.nextInt();
							int h = inF.nextInt();
							
							ThreeDRectangle tempR = new ThreeDRectangle(w,l,h);
							System.out.println("The Area of a ThreeDRectangle with the lenght of " + l + " and Width of " + w + " and Height of " + h+" = "+ tempR.getArea());}
						//else {System.out.println("Invalid input");}
						b= false;}
				inF.close();}
			
			
			// when the input is !exit
			else if (s1.equals("!exit")) {
				System.out.println("Thank You Have a Nice Day");
				System.exit(0);}
		
			// when the input is other strings
			else{
				System.out.println("Invavid command");
			}
		}
		
		inS.close();
	}
}
