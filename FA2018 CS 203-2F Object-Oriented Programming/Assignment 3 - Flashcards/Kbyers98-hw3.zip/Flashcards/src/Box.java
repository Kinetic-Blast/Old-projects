import java.util.ArrayList;
import java.util.List;
/**
 * Creates boxes for use in the flash card system
 * @author Baylee Byers
 * @version 1.0
 *
 */
public class Box{
	
	//keeps the total amount of boxes for later but for some reason its set 10 and i dont know why
	private static int NumberOfboxes;
	private List<Cards> Box;
	private int Number; //if the full function was added this would keep track of the box number
	
	public String Name;
	
	public Box() {
		super();}
	/**
	 * creates a Box object requires name of the object and assigns it a number in the order that it gets created
	 * @param name -Sting names the box
	 */
	public Box(String name) {
		Name = name;
		Number = NumberOfboxes - 10;
		NumberOfboxes ++;
		Box = new ArrayList<Cards>();}
	
	/**
	 * Gets the name of the box and reutrns it
	 * @return Sting - name of the box
	 */
	public String getBoxName() {
		return Name;}
	
	/**
	 * checks to see if card is the box 
	 * @param arg0 - the card your looking for
	 * @return boolean value true or false if the card it in the box or not 
	 */
	public boolean contains(Cards arg0) {
		return Box.contains(arg0);}
	
	/**
	 * checks to see if the box does not have the card 
	 * @param arg0 - the card your looking for
	 * @return boolean value if it has it returns false if it doesn't it returns true
	 */
	public boolean doesnotcontain(Cards arg0) {
		return !Box.contains(arg0);}
	
	/**
	 * Sets the name of the box to what is specified
	 * @param arg0 - String new name of the box
	 */
	public void setBoxName(String arg0) {
		Name = arg0;}
	
	//should be number that they were created in
	/**
	 * gets the number given to the box when it was created
	 * @return Number - int the boxes number
	 */
	public int getBoxNumber() {
		return Number;}
	
	/**
	 * adds a card to the box
	 * @param arg0 - Card that you want to be in the box
	 */
	public void addToBox(Cards arg0) {
		if (Box.contains(arg0)) {System.out.println("["+ arg0 +"]"+ " is already in " + getBoxName());}
		else {Box.add(arg0);}}
	
	/**
	 * Removes the card from the box
	 * @param arg0 - Card that you want removed from the box
	 */
	public void rfromBox(Cards arg0) {
		if (Box.contains(arg0)){
			Box.remove(arg0);}
			//System.out.println(arg0+" was removed from "+this.getBoxName());}
		else {System.out.println(arg0 +" does not exist in this box");}}
	
	/**
	 * toString makes the box and its items with in into a String for use
	 */
	public String toString() {
		String arg0= this.getBoxName()+" "+Box.toString();
		return arg0;}}
