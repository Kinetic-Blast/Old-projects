

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class BookStoreTest {

	private BookStore store;
	private Book b1 = new Book(1, "Harper Lee", "To Kill a Mockingbird");
	private Book b2 = new Book(2, "Harper Lee", "To Kill a Mockingbird");
	private Book b3 = new Book(3, "Frances Hodgson", "The Secret Garden");
	private Book b4 = new Book(5, "J.K. Rowling",
			"Harry Potter and the Sorcerer's Stone");
	private Book b5 = new Book(4, "Douglas Adams",
			"The Hitchhiker's Guide to the Galaxy");



	/**
	 * setup the store
	 * 
	 */
	@Before
	public void setUpBookStore() {
		store = new BookStore();
		store.addBook(b1);
		store.addBook(b2);
		store.addBook(b3);
		store.addBook(b4);

	}

	/**
	 * tests the addition of book
	 * 
	 */

	@Test
	public void testAddBook() {
		store.addBook(b1);
		assertTrue(store.getBooks().contains(b1));

	}

	/**
	 * tests the deletion of book
	 * 
	 */

	@Test
	public void testDeleteBook() {
		store.deleteBook(b2);
		assertFalse(store.getBooks().contains(b2));
	}

	/**
	 * tests sorting of books by author name
	 * 
	 */

	@Test
	public void testGetBooksSortedByAuthor() {
		List <Book> Temps = store.getBooksSortedByAuthor();
		List<Book>Temps2 = new ArrayList<Book>();
		Temps2.add(b3);
		Temps2.add(b1);
		Temps2.add(b2);
		Temps2.add(b4);
		assertTrue(Temps.get(0).equals(Temps2.get(0)) & Temps.get(3).equals(Temps2.get(3)));

	}

	/**
	 * tests sorting of books by title
	 * 
	 */

	@Test
	public void testGetBooksSortedByTitle() {
		List <Book> Temps = store.getBooksSortedByTitle();
		List<Book>Temps2 = new ArrayList<Book>();
		Temps2.add(b4);
		Temps2.add(b3);
		Temps2.add(b1);
		Temps2.add(b2);
		assertTrue(Temps.get(0).equals(Temps2.get(0)) & Temps.get(3).equals(Temps2.get(3)));
		

	}

	/**
	 * tests the number of copies of book in store
	 * 
	 */

	@Test
	public void testCountBookWithTitle() {
		String tmp = b1.getTitle();
		String tmp2 = b4.getTitle();
		System.out.println(store.countBookWithTitle(tmp));
		System.out.println(store.countBookWithTitle(tmp2));
		
		assertTrue(store.countBookWithTitle(tmp) == 2 & store.countBookWithTitle(tmp2) == 1);

	}

}
