

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.Timer;

/** A simple tetromino viewer. */
public class TetrisViewer
{
  /** size of frame. */
  //private static final int FRAMESZ = Tetromino.BLOCK * (Tetromino.COUNT+1); //can be changed
	
	private static final int FRAMES1 = 12*26+10;
	private static final int FRAMES2 = 26*23+25;
	
  /** maximum number of rotations. */
  private static final int MAXROTATE = 4; //may not need but who knows 

  /**
   * The main method.
   *
   * @param args command line arguments; currently ignored.
   */
  public static void main(String[] args)
  {
    // create random tetromino
    Random          rand   = new Random();
    Tetromino       piece  = new Tetromino(rand.nextInt(Tetromino.COUNT));

    // set tetromino's position randomly
    //piece.setX(rand.nextInt(FRAMESZ - Tetromino.BLOCK)); //can be changed needs to have default and can change later using translate
    //piece.setY(rand.nextInt(FRAMESZ - Tetromino.BLOCK));
    
    piece.setX(100);
    piece.setY(0);

    // rotate tetromino a random number of times
    int degree = rand.nextInt(MAXROTATE);
    piece.rotateCCW90(degree); // count up to four and reset to zero leave this part alone needs to spawn with random ration

    // create component and set tetromino
    TetrisComponent field  = new TetrisComponent();

    field.setPiece(piece);

    // create and setup frame
    JFrame          frame  = new JFrame();

    frame.setSize(FRAMES1, FRAMES2);
    frame.setTitle("Tetromino");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.add(field);
    frame.setVisible(true);
    
    int Time = 500;
	new Timer (Time , e -> {
		piece.Move();
		field.repaint();}).start();
	
	field.addKeyListener(new KeyListener () {

		@Override
		public void keyPressed(KeyEvent e) {
			field.LRRmove(e,degree);
		}

		@Override
		public void keyReleased(KeyEvent e) {
		}

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}});
	field.setFocusable(true);
	field.requestFocus();
}}
