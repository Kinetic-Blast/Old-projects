

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import javax.swing.JComponent;
import java.util.Random;

/**
 * This component draws tetrominos.
 */
public class TetrisComponent extends JComponent
{
	private boolean goDown = true;
	
	
  /**
   * Method to draw all tetromino shapes on the screen.
   *
   * @param g a graphics object
   */
  public void paintComponent(Graphics g)
  {
    // tetromino must be set before we can paint it.
    assert tetromino != null;

    Graphics2D g2 = (Graphics2D) g;

    // solution code
    tetromino.draw(g2);}

  /**
   * Sets the current tetromino.
   *
   * @param piece a valid tetromino
   */
  public void setPiece(Tetromino piece){
	  tetromino = piece;}

  /** The component's tetromino. */
  private Tetromino tetromino;

  /**
   * Moves the Piece right left and rotates it
   */
  public void LRRmove(KeyEvent e, int degree) {
	int keyPressed = e.getKeyCode();
		
	if (tetromino.getY() <= 500) {	
		if (keyPressed == KeyEvent.VK_UP) {
			tetromino.rotateCCW90(degree+1);}
		
		if (keyPressed == KeyEvent.VK_RIGHT && tetromino.getX() != 240){
			tetromino.setX(tetromino.getX()+10);}
		
		if (keyPressed == KeyEvent.VK_LEFT && tetromino.getX() != 0){
			tetromino.setX(tetromino.getX()-10);}
		repaint();
	
}}}

