

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class BookStoreTest {

	private static BookStore setupBookStore() {
		BookStore b = new BookStore();
		b.addBook(new Book(1, "Harper Lee", "To Kill a Mockingbird"));
		b.addBook(new Book(2, "Harper Lee", "To Kill a Mockingbird"));
		b.addBook(new Book(3, "Frances Hodgson", "The Secret Garden"));
		b.addBook(new Book(5, "J.K. Rowling",
				"Harry Potter and the Sorcerer's Stone"));
		return b;
	}

	private static boolean testAddBook() throws NoSuchFieldException, IllegalAccessException {
		BookStore store = setupBookStore();
		Book b = new Book(4, "Douglas Adams",
				"The Hitchhiker's Guide to the Galaxy");
		store.addBook(b);

		// Isolate class information, get private List field, set List to accessible, access private list object
		Class<?> bookStoreClass = store.getClass();

		Field arrayListField = bookStoreClass.getDeclaredField("books");
		arrayListField.setAccessible(true);

		List<Book> internalBookList = (List<Book>) arrayListField.get(store);

		return internalBookList.contains(b);}

	private static boolean testDeleteBook() throws NoSuchFieldException, IllegalAccessException {
		BookStore store = setupBookStore();
		Book b = new Book(4, "Douglas Adams",
				"The Hitchhiker's Guide to the Galaxy");
		store.addBook(b);
		store.deleteBook(b);
		
		Class<?> bookStoreClass = store.getClass();

		Field arrayListField = bookStoreClass.getDeclaredField("books");
		arrayListField.setAccessible(true);

		List<Book> internalBookList = (List<Book>) arrayListField.get(store);

		return !internalBookList.contains(b);}

	private static boolean testGetBooksSortedByAuthor() throws NoSuchFieldException, IllegalAccessException {
		BookStore store = setupBookStore();
		List<Book> test = new ArrayList<Book>();
		
		List<Book> temp = store.getBooksSortedByAuthor();
		
		test.add(new Book(3, "Frances Hodgson", "The Secret Garden"));
		test.add(new Book(1, "Harper Lee", "To Kill a Mockingbird"));
		test.add(new Book(2, "Harper Lee", "To Kill a Mockingbird"));
		test.add(new Book(5, "J.K. Rowling","Harry Potter and the Sorcerer's Stone"));
		
		for(int i =0; i < test.size(); i++) {
			String check = test.get(i).getAuthorName();
			String check2 = temp.get(i).getAuthorName();
			
			if (!check.equals(check2))return false;}
		
		
		return true;}

	private static boolean testGetBooksSortedByTitle() throws NoSuchFieldException, IllegalAccessException {
		BookStore store = setupBookStore();
		List<Book> test = new ArrayList<Book>();
		
		List<Book> temp = store.getBooksSortedByTitle();
		
		test.add(new Book(5, "J.K. Rowling","Harry Potter and the Sorcerer's Stone"));
		test.add(new Book(3, "Frances Hodgson", "The Secret Garden"));
		test.add(new Book(1, "Harper Lee", "To Kill a Mockingbird"));
		test.add(new Book(2, "Harper Lee", "To Kill a Mockingbird"));
		
		for(int i =0; i < test.size(); i++) {
			String check = test.get(i).getTitle();
			String check2 = temp.get(i).getTitle();
			
			if (!check.equals(check2))return false;}
		
		
		return true;}

	private static boolean testCountBookWithTitle() throws NoSuchFieldException, IllegalAccessException {
		BookStore store = setupBookStore();
		
		int test1 = store.countBookWithTitle("To Kill a Mockingbird");
		int test2 = store.countBookWithTitle("The Secret Garden");
		int test3 = store.countBookWithTitle("Harry Potter and the Sorcerer's Stone");
		if (!(test1 == 2)) return false;
		if (!(test2 == 1)) return false;
		if (!(test3 == 1)) return false;
		return true;}


	public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {

		System.out.println(String.format("Test Add Book: %s", testAddBook()));
		System.out.println(String.format("Test Delete Book: %s", testDeleteBook()));
		System.out.println(String.format("Test Get Books Sorted By Author: %s", testGetBooksSortedByAuthor()));
		System.out.println(String.format("Test Get Books Sorted By Title: %s", testGetBooksSortedByTitle()));
		System.out.println(String.format("Test Count Book With Title: %s", testCountBookWithTitle()));

	}


}
