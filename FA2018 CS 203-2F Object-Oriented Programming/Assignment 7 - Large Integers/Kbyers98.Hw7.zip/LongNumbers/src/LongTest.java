import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LongTest {

	@Test
	public static void main(String args[]){
        String s1 = "1000000000";
        String s2 = "5";
        System.out.println(div(s1, s2));}}
	}

}
