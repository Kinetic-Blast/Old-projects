import java.util.ArrayList;
import java.util.Collections;

public class Long {

	/**
	 * Adds two numbers does not work with negative numbers unless both are negative i was going to rely on subtraction to handle this but i could not get it working to a degree i would call accurate
	 * @param num1 - String does not like letters
	 * @param num2 - string does not like letters
	 * @return String of the numbers added together
	 */
	public static String add(String num1, String num2){
		
		boolean check1= true;
		boolean check2= true;
		String temp = null;
		
		if (num1.charAt(0)=='-') {
	    	num1 = num1.substring(1,num1.length());
	    	check1 = false;}
	    
	    if (num2.charAt(0)=='-') {
	    	num2 = num2.substring(1,num2.length());
	    	check2 = false;}
	    
	    //Subtraction if one was neg could not get sub to work to any degree i would call functioning
	    //if (check1 == false && check2 == !false || check1 == !false && check2 == false) {
	    	//if (check1 == false) {temp = sub(num1,num2);}
	    	//if (check2 == false) {temp = sub(num1,num2);}
	    	//return temp;}
	    
		int i = num1.length() - 1;
		int j = num2.length() - 1;
		int carry = 0;
		
	    StringBuilder sb = new StringBuilder();
	    
	    while(i >= 0 || j >= 0 || carry != 0) {
	        if(i >= 0) carry += num1.charAt(i--) - '0';
	        if(j >= 0) carry += num2.charAt(j--) - '0';
	        sb.append(carry % 10);
	        carry /= 10;}
	    
	    temp = sb.reverse().toString();
	    
	    if (check1 ==false && check2 == false) {
	    	return "-"+temp;}
	    
	    return temp;}
	
	/**
	 * Multiplies the two given numbers both positive and negatives
	 * @param num1 -String does not like letters
	 * @param num2 -String does not like letters
	 * @return String of the numbers Multiplied together
	 */
	public static String mul(String num1, String num2) {
		
		boolean check1 = true;
		boolean check2 = true;
		
	    String n1 = new StringBuilder(num1).reverse().toString();
	    String n2 = new StringBuilder(num2).reverse().toString();
	    
	    if (n1.charAt(n1.length()-1)=='-') {
	    	n1 = n1.substring(0,n1.length()-1);
	    	check1 = false;}
	    
	    if (n2.charAt(n2.length()-1)=='-') {
	    	n2 = n2.substring(0,n2.length()-1);
	    	check2 = false;}
	    
	 
	    int[] d = new int[n1.length()+n2.length()];
	 
	    //multiply each digit and sum at the corresponding positions
	    for(int i=0; i<n1.length(); i++){
	        for(int j=0; j<n2.length(); j++){
	            d[i+j] += (n1.charAt(i)-'0') * (n2.charAt(j)-'0');}}
	 
	    StringBuilder sb = new StringBuilder();
	 
	    //calculate each digit
	    for(int i=0; i<d.length; i++){
	        int mod = d[i]%10;
	        int carry = d[i]/10;
	        if(i+1<d.length){
	            d[i+1] += carry;}
	        sb.insert(0, mod);}
	 
	    //remove front 0's
	    while(sb.charAt(0) == '0' && sb.length()> 1){
	        sb.deleteCharAt(0);}
	    
	    //negative handling 
	    if(check1 ==  false && check2 == false) {
	    	return sb.toString();}
	    
	    if(check1==false || check2 == false) {
	    	return ("-"+sb.toString());}
	    return sb.toString();}
	
	//ran out of time for negative handling
	/**
	 * Divides the two numbers the largest number will be the one divided does not handle negatives
	 * @param divid -String does not like letters
	 * @param divis -String does not like letters
	 * @return String of the divided numbers does not provide remainders. and does not return a full number if using one 
	 */
	public static String div(String divid, String divis) {
		
		if (divid.length() < divis.length()) {
			String temp = divid;
			divid = divis;
			divis = temp;;}
		
		String result ="";
		
		int remainder= 0;
		int IntNumGet = divis.length();
		int currentInt = 0;
		int divi = Integer.parseInt(divid.substring(currentInt,IntNumGet));
		
		int intdivis = Integer.parseInt(divis);
		
		
		
		while (currentInt < divid.length()) {
			
			if (divi == 0) {
				currentInt++;
				result += "0";}
			else {
				while (divi < intdivis) {
					IntNumGet++;
					divi = Integer.parseInt(divid.substring(currentInt,IntNumGet));}
				
				if (divi >0) {
					remainder = divi % intdivis;
					result += ((divi - remainder)/ intdivis);
					IntNumGet = 1;
					
					if (currentInt < divid.length()-2) {
						currentInt +=2;}
					else {
						currentInt++;}
					
					if (currentInt != divid.length()) {
						divi = Integer.parseInt(divid.substring(currentInt));
						remainder *= 10;
						divi += remainder;}}}}
		
		if (result.length() > (divid.length() -intdivis)) {
			result = result.substring(0, divid.length()-divis.length());}
		
		if (result.length() > 3) {
			result += "0";}
		
		return result;}
            
    public static void main(String args[]){
        String s1 = "1000000000";
        String s2 = "5";
        String s3 = "25";
        String s4 = "10";
       
        System.out.println(add(s1,s1));
        System.out.println(add(s1,s2));
        System.out.println(add(s1,s3));
        System.out.println(add(s1,s4));
        
        System.out.println(add(s2,s1));
        System.out.println(add(s2,s2));
        System.out.println(add(s2,s3));
        System.out.println(add(s2,s4));
        
        System.out.println(add(s3,s1));
        System.out.println(add(s3,s2));
        System.out.println(add(s3,s3));
        System.out.println(add(s3,s4));
        
        System.out.println(add(s4,s1));
        System.out.println(add(s4,s2));
        System.out.println(add(s4,s3));
        System.out.println(add(s4,s4));
        
        System.out.println("---------------------------");
        System.out.println(mul(s1,s1));
        System.out.println(mul(s1,s2));
        System.out.println(mul(s1,s3));
        System.out.println(mul(s1,s4));
        
        System.out.println(mul(s2,s1));
        System.out.println(mul(s2,s2));
        System.out.println(mul(s2,s3));
        System.out.println(mul(s2,s4));
        
        System.out.println(mul(s3,s1));
        System.out.println(mul(s3,s2));
        System.out.println(mul(s3,s3));
        System.out.println(mul(s3,s4));
        
        System.out.println(mul(s4,s1));
        System.out.println(mul(s4,s2));
        System.out.println(mul(s4,s3));
        System.out.println(mul(s4,s4));
        
        System.out.println("---------------------------");
        
        System.out.println(div(s1, s2));
        System.out.println(div(s1, s3));
        System.out.println(div(s1, s4));
        System.out.println(div(s2, s1));
        System.out.println(div(s2, s3));
        System.out.println(div(s2, s4));
        System.out.println(div(s1, s2));}}


// add does not have the ability to handle negatives
//multiply does have the ability to handle negatives
// divide does not have the ability to handle negatives and some of its answers are not all ways correct for numbers that do not go into each other perfectly does not handle decimal places and some reason it does not
//have the ability to divide correctly some times
