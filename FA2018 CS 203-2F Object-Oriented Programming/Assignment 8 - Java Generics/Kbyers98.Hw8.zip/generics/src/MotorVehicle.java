

public class MotorVehicle extends Vehicle
{
  /**
   * Creates a new Vehicle object.
   *
   * @param desc  description
   * @param seats max. number of people
   * @param mpg   gas mileage
   */
  public MotorVehicle(String desc, int seats, double mpg)
  {
    super(desc, seats);

    this.mpg = mpg;
  }

  /**
   * Compares this to other.
   *
   * @param other some other MotorVehicle
   * @return negative iff this < other
   *         0 iff this == other
   *         positive iff this > other
   */
  public int compareTo(Object other)
  {
    int res = super.compareTo(other);

    if (res != 0) return res;

    if (other instanceof MotorVehicle)
    {
      MotorVehicle that = (MotorVehicle) other;

      res = this.mpg.compareTo(that.mpg);
    }

    return res;
  }

  /**
   * Returns a textual description.
   *
   * @return a text
   */
  public String toString()
  {
    return super.toString() + " " + mpg;
  }

  /** mpg. */
  private Double mpg;
}
