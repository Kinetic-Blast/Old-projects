

public class Bike extends Vehicle
{
  /**
   * Creates a new Vehicle object.
   *
   * @param desc  description
   * @param seats max. number of people
   * @param gears number of gears
   */
  public Bike(String desc, int seats, int gears)
  {
    super(desc, seats);

    this.gears = gears;
  }

  /**
   * Compares this to other.
   *
   * @param other some other Bike
   * @return negative iff this < other
   *         0 iff this == other
   *         positive iff this > other
   */
  public int compareTo(Object other)
  {
    int res = super.compareTo(other);

    if (res != 0) return res;

    if (other instanceof Bike)
    {
      Bike that = (Bike) other;

      res = this.gears - that.gears;
    }

    return res;
  }

  /**
   * Returns a textual description.
   *
   * @return a text
   */
  public String toString()
  {
    return super.toString() + " " + gears;
  }

  /** gears. */
  private int gears;
}
