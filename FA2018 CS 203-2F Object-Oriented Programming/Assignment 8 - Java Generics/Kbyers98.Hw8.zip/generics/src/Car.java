

public class Car extends MotorVehicle
{
  /**
   * Creates a new Vehicle object.
   *
   * @param desc  description
   * @param seats max. number of people
   * @param mpg   gas mileage
   * @param make  name of make
   */
  public Car(String desc, int seats, double mpg, String make)
  {
    super(desc, seats, mpg);

    this.make = make;
  }

  /**
   * Compares this to other.
   *
   * @param other some other Car
   * @return negative iff this < other
   *         0 iff this == other
   *         positive iff this > other
   */
  public int compareTo(Object other)
  {
    int res = super.compareTo(other);

    if (res != 0) return res;

    if (other instanceof Car)
    {
      Car that = (Car) other;

      res = this.make.compareTo(that.make);
    }

    return res;
  }

  /**
   * Returns a textual description.
   *
   * @return a text
   */
  public String toString()
  {
    return super.toString() + " " + make;
  }

  /** make. */
  private String make;
}
