

public class Vehicle implements Comparable
{
  /** secret constructor. */
  private Vehicle() {}

  /**
   * Creates a new Vehicle object.
   *
   * @param desc  description
   * @param seats max. number of people
   */
  public Vehicle(String desc, int seats)
  {
    description = desc;
    capacity    = seats;
  }

  /**
   * Compares this to other.
   *
   * @param other some other Vehicle
   * @return negative iff this < other
   *         0 iff this == other
   *         positive iff this > other
   */
  public int compareTo(Object other)
  {
    // if the real type is different, just compare the real type
    Vehicle that = (Vehicle) other;
    int     res = this.capacity - that.capacity;

    if (res != 0) return res;

    return this.description.compareTo(that.description);
  }

  /**
   * Returns a textual description.
   *
   * @return a text
   */
  public String toString()
  {
    return description + " " + capacity;
  }

  /** capacity. */
  private int    capacity;

  /** description. */
  private String description;
}
