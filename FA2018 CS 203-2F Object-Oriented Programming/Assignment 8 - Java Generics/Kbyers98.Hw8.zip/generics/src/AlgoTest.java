import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AlgoTest {

	@Test
	void testCopyIf() {
		fail("Not yet implemented");
	}

	@Test
	void testCopyIfGreaterThan() {
		fail("Not yet implemented");
	}

	@Test
	void testFindMaxListOfEComparatorOfE() {
		fail("Not yet implemented");
	}

	@Test
	void testFindMaxListOfE() {
		fail("Not yet implemented");
	}

	@Test
	void testStoreMin() {
		fail("Not yet implemented");
	}

	@Test
	void testSelectionSortArrayListOfEComparatorOfE() {
		fail("Not yet implemented");
	}

	@Test
	void testSelectionSortArrayListOfE() {
		fail("Not yet implemented");
	}

}
