

interface UnaryPredicate
{
  boolean test(Object obj);
}
