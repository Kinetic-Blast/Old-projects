

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Comparator;

/**
 * Implements frequently used algorithms.
 */
public class Algo
{
  /**
   * returns a comparator object that uses compareTo of Comparable objects.
   *
   * @return a comparator object
   */
  static private
  <E extends Comparable<? super E>>
  Comparator<E> defaultComparator()
  {
    return new Comparator<E>() {
             public int compare(E one, E two)
             {
               assert one instanceof Comparable;

               return ((E)one).compareTo(two);
             }
           };
  }

  /**
   * Copies all objects from src to tgt, for which the predicate pred holds.
   *
   * @param src source list
   * @param tgt target list
   * @param pred unary predicate
   */
  static public
  <F, E extends F>
  void copyIf(List<E> src, List<F> tgt, UnaryPredicate pred)
  {
    for (F obj : src)
    {
      if (pred.test(obj)) tgt.add(obj);
    }
  }

  /**
   * Copies all objects from src to tgt that are greater than yardstick.
   *
   * @param src source
   * @param tgt target
   * @param yardstick determines if objects in src should be copied to tgt.
   */
  static public
  <E extends F, F extends Comparable<? super F>>
  void copyIfGreaterThan(List<E> src, List<F> tgt, final Comparable<F> yardstick)
  {
    copyIf(src, tgt, new UnaryPredicate() {
      @SuppressWarnings("unchecked")
	public boolean test(Object o)
      {
        return yardstick.compareTo((F) o) < 0;
      }
    });
  }

  /**
   * Finds a maximum object in lst.
   *
   * @param lst a list containing non-null references
   * @param comp comparator defines order between two objects in lst
   * @return a maximum object in lst; null if the lst is empty
   */
  static public
  <E extends Comparable<? super E>>
  Object findMax(List<E> lst, Comparator<E> comp)
  {
    assert lst != null;
    assert comp != null;

    E max  = null;
    Iterator<E> iter = lst.iterator();

    // handle first element
    if (iter.hasNext())
      max = iter.next();

    // handle remaining elements
    while (iter.hasNext())
    {
      assert max != null;

      E cand = iter.next();

      if (comp.compare(max, cand) < 0)
        max = cand;
    }

    return max;
  }

  /**
   * Finds a maximum object in lst.
   *
   * @param lst a list containing non-null references
   * @return a maximum object in lst; null if the lst is empty
   */
  static public
  <E extends Comparable<? super E>>
  Comparable<?> findMax(List<E> lst)
  {
	if(lst.size() == 0) return null;
	
	E max = lst.get(0);
	for (E obj:lst)
		if (obj.compareTo(max)>0) max = obj;
    return (Comparable<?>) findMax(lst, defaultComparator());
  }


  /**
   * Adds the smaller of lhs and rhs to dst.
   *
   * @param lhs left hand side object
   * @param rhs right hand side object
   * @param dst destination list
   */
  static public
  <E extends Comparable<? super E>>
  void storeMin(E lhs, E rhs, List<E> dst)
  {
    E min = lhs;

    if (min.compareTo(rhs) > 0) min = rhs;

    dst.add(min);
  }

  /**
   * swaps the elements at a and b in lst.
   *
   * @param lst a list
   * @param a first location in lst
   * @param b second location in lst
   */
  static private
  <T>
  void swap(ArrayList<T> objs, int a, int b)
  {
    T tmp = objs.get(a);

    objs.set(a, objs.get(b));
    objs.set(b, tmp);}

  /**
   * Sorts the elements in lst according to criteria specified in comp.
   *
   * @param lst an array list containing non-null references
   * @param comp comparator defines order between two objects in lst
   */
  static public
  <E extends Comparable<? super E>>
  void selectionSort(ArrayList<E> lst, Comparator<E> comp)
  {
    for (int i = 0; i < lst.size(); ++i)
    {
      int min = i;

      for (int j = i+1; j < lst.size(); ++j)
      {
        if (comp.compare(lst.get(min), lst.get(j)) > 0)
          min = j;
      }

      swap(lst, min, i);
    }
  }

  /**
   * Sorts the elements in lst.
   *
   * @param lst an array list containing non-null references
   */
  static public
  <E extends Comparable<? super E>>
  void selectionSort(ArrayList<E> lst)
  {
    // call selection sort with built-in comparison
    selectionSort(lst, defaultComparator());
  }
}
