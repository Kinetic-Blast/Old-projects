import java.io.IOException;

public class Main extends FlashCardApp{

	public Main(String question, String awnser) {
		super(question, awnser);}
	
	public static void main (String[] args) throws IOException {
		getcards();
		App();}}
