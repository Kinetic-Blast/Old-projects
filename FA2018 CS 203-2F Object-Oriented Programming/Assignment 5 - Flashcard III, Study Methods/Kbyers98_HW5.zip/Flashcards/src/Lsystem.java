
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Lsystem extends Cards{
	static ArrayList<Lsystem> CardList = new ArrayList<Lsystem>();
	static ArrayList<Lsystem> CardListCheck = new ArrayList<Lsystem>();
	
	private static Box box1 = new Box ("Box 1");
	private static Box box2 = new Box ("Box 2");
	private static Box box3 = new Box ("Box 3");
	private static Box box4 = new Box ("Box 4");
	private static Box box5 = new Box ("Box 5");
	
	/**
	 * Build the Flash Cards that are allowed to run in the system
	 * @param question
	 * @param awnser
	 */
	public Lsystem(String question, String awnser) {
		super(question, awnser);
		CardList.add(this);
		box1.addToBox(this);}
	/**
	 * list all cards that are in the system
	 * @return String of cards
	 */
	public static String ListAllCards() {
		System.out.println(CardList.toString());
		return CardList.toString();}
	
	/**
	 * Searches add finds the box that the card is in
	 * @return Box object that has the card in it 
	 */
	public Box Finditsbox() {
		if(box1.contains(this)) {
			return box1;}
		if(box2.contains(this)) {
			return box2;}
		if(box3.contains(this)) {
			return box3;}
		if(box4.contains(this)) {
			return box4;}
		if(box5.contains(this)) {
			return box5;}
		else {box1.addToBox(this);
			System.out.println("not able to find the box this was in added to box 1");
			return box1;}}
	/**
	 * Finds the Box that is above the cards Current box
	 * @return Box Object that is above the cards current box
	 */
	public Box FindUpperBox() {
		if(box1.contains(this)) {
			return box2;}
		if(box2.contains(this)) {
			return box3;}
		if(box3.contains(this)) {
			return box4;}
		if(box4.contains(this)) {
			return box5;}
		if(box5.contains(this)) {
			return box5;}
		else {box1.addToBox(this);
			System.out.println("not able to find the box this was in added to box 1");
			return box2;}}
	/**
	 * Finds the box That is under the Current Box
	 * @return Box Object that is under the cards current box
	 */
	public Box FindLowerBox() {
		if(box1.contains(this)) {
			return box1;}
		if(box2.contains(this)) {
			return box1;}
		if(box3.contains(this)) {
			return box2;}
		if(box4.contains(this)) {
			return box3;}
		if(box5.contains(this)) {
			return box4;}
		else {box1.addToBox(this);
			System.out.println("not able to find the box this was in added to box 1");
			return box1;}}
	/**
	 * Adds the card to the lower box and removes it from the higher box
	 */
	public void addTolower() {
		Box temp = this.Finditsbox();
		Box temp2 = this.FindLowerBox();
		
		temp.rfromBox(this);
		temp2.addToBox(this);}
	/**
	 * Adds the card to the higher box and removes it from the lower box
	 */
	public void addToUpper() {
		Box temp = this.Finditsbox();
		Box temp2 = this.FindUpperBox();
		temp.rfromBox(this);
		temp2.addToBox(this);}
	/**
	 *Gets the Number of Cards in the main list
	 * @return Int number of total cards
	 */
	public int GetNumCard() {
		return CardList.size();}
	/**
	 * gets the number of cards that are left in play for the current loop of the game
	 * @return Int Number of cards left in one round
	 */
	public static int GetNumCardLeft() {
		return CardListCheck.size();}
	/**
	 * Gets the Answer if the user flips the card
	 * @return the Answer of the question
	 */
	public String flip() {
		return this.getAwnser();}
	/**
	 * List out all boxes
	 */
	public static void allBoxes() {
		System.out.println(box1);
		System.out.println(box2);
		System.out.println(box3);
		System.out.println(box4);
		System.out.println(box5);}
	
	/**
	 * Imports a file for use to create Cards
	 * @param arg0
	 * @throws FileNotFoundException
	 */
	public static void importfile(String arg0) throws FileNotFoundException {
		//file must follow rule of FlashCard Question Answer and /n for the next card
		Scanner inF = new Scanner(new File(arg0));
		while (inF.hasNextLine()) {
			String temp = inF.next();
			
			if (temp.equals("FlashCard")) {
				String question = inF.next();
				String awnser = inF.next();
				new Lsystem(question,awnser);}}}
	/**
	 * Scans for cards that meet what was searched
	 * @param arg0
	 * @return List object of all cards that meat that search
	 */
	public static List<Lsystem> SearchFor(String arg0) {
		List<Lsystem> temp = new ArrayList<Lsystem>();
		for (Lsystem s : CardList) {
			if (s.contains(arg0)) {
				temp.add(s);}}
		System.out.println("All Cards that meet the search cirteria of: " + arg0+ " : " + temp.toString());
		return temp;}
	/**
	 * Randomly scans for a card in all the boxes with a card in it a has a multiplier effect on what gets chosen
	 * @return 
	 */
	public static Lsystem rcardselection() {
		Random rnum = new Random();
		int temp = rnum.nextInt(31)+1;
		
		if (temp <= 16 && box1.getsize() != 0) {
			int temp2 = rnum.nextInt(box1.getsize());
			Lsystem card = box1.getItem(temp2);
			if (card.contains(card)) {return card;}
			else {rcardselection();}}
		
		if (temp<=24 && temp > 16 && box2.getsize() != 0) {
			int temp2 = rnum.nextInt(box2.getsize());
			Lsystem card = box2.getItem(temp2);
			if (card.contains(card)) {return card;}
			else {rcardselection();}}
		
		if (temp<=28 && temp > 24 && box3.getsize() != 0) {
			int temp2 = rnum.nextInt(box3.getsize());
			Lsystem card = box3.getItem(temp2);
			if (card.contains(card)) {return card;}
			else {rcardselection();}}
		
		if (temp<=30 && temp > 28 && box4.getsize() != 0) {
			int temp2 = rnum.nextInt(box4.getsize());
			Lsystem card = box4.getItem(temp2);
			if (card.contains(card)) {return card;}
			else {rcardselection();}}
		
		if (temp<=31 && temp > 30&& box5.getsize() != 0) {
			int temp2 = rnum.nextInt(box5.getsize());
			Lsystem card = box5.getItem(temp2);
			if (card.contains(card)) {return card;}
			else {rcardselection();}}
		return null;}	
	/**
	 * Allows the search for card objects
	 * @param card
	 * @return Boolean if card is in play for that round
	 */
	public boolean contains(Lsystem card) {
		return CardList.contains(card);}
	/**
	 * Checks to see if that a particular string is in any cards
	 * @param string
	 * @return Boolean if the string is in play on any cards 
	 */
	public boolean contains(String string) {
		return CardList.contains(string);}
	/**
	 * Gets the box object for use in the simple study method
	 * @param temp
	 * @return Box object
	 */
	public static Box simpleStudyBox(int temp) {
		if(temp == 1) {return box1;}
		if(temp == 2) {return box2;}
		if(temp == 3) {return box3;}
		if(temp == 4) {return box4;}
		if(temp == 5) {return box5;}
		else {simpleStudyBox(temp); return null;}
		
		
	}
}