
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class FlashCardApp extends Lsystem{
	
	public FlashCardApp(String question, String awnser) {
		super(question, awnser);}
	/**
	 * Case System that runs the input of the cards 
	 * @throws FileNotFoundException
	 */
	public static void getcards() throws FileNotFoundException {
		
		boolean loop = true;
		int check;
		Scanner inn = new Scanner(System.in);
		
		System.out.println("\n Specify The File You Would Like To Use: \n For Coustom File input: 1 \n For The Defalut File input: 2 \n Or For Coustom Cards input: 3 \n To Exit Input: 4");
		System.out.println("\n Input: ");
		
		check = inn.nextInt();
		
		switch(check) {
			case 1: 
				System.out.println("You Chose to Input a file please provide the name of the file (example.txt) to go back input (back)");
				System.out.println("Import File: ");
				String File = inn.next();
				
				if (File.toLowerCase().equals("back")) {getcards();
				break;}
				
				importfile(File);
				
				break;
			case 2:
				System.out.println("You Chose to Use the Defalut File is this correct (y/n)");
				String Temp = inn.next();
				
				if (Temp.toLowerCase().equals("n")) {getcards();}
				else {importfile("default.txt");}
				break;
			case 3:
				System.out.println("You Chose to Use the Coustom Inputs is this correct (y/n)");
				String Temp2 = inn.next();
				if (Temp2.toLowerCase().equals("n")) {getcards();}
				System.out.println("To exit and complete the flash cards input: done \n To Return and use another input system input: addMore");
				
				while(loop) {
					System.out.println("Input Question: ");
					String Q = inn.next();
					
					if (Q.toLowerCase().equals("done")) {break;}
					if (Q.toLowerCase().equals("addmore")) {getcards();}
					
					System.out.println("Input Awnser: ");
					String A = inn.next();
					
					if (A.toLowerCase().equals("done")) {break;}
					if (A.toLowerCase().equals("addmore")) {getcards();}
					
					new Lsystem(Q,A);}
				
				break;
			case 4:
					System.exit(0);
			default:
				System.out.println("Please select correct option");
				getcards();}}
	/**
	 * The Application that runs the system and calls the other functions
	 * @throws IOException
	 */
	public static void App() throws IOException {
		boolean loop =true; 
		int check;
		boolean newcard = true;
		Lsystem temp = null;
		
		while (loop == true) {
			Scanner in = new Scanner(System.in);
			
			if (newcard == true) {temp = rcardselection();}
			
			while (temp == null){
				temp = rcardselection();}
					
			newcard = false;
			
			
			System.out.println("\n To Input the Awnser Input :1  \n Search for a Card Input: 2  \n List all cards Input : 3 "
					+ "\n To List all cards in Boxes Input: 4 \n to run a simple study method input: 5 " + "\n to run the drill method input: 6"
					+ "\n To Exit input: 7");
			
			System.out.println("\n Question:" +temp.getQuestion());
			
			check = in.nextInt();
			
			switch(check) {
				case 1:
					boolean loop2 = true;
					while (loop2) {
						String awnser = temp.getAwnser();
						System.out.println("Input Awnser: ");
						String userA = in.next();
						
						if (userA.toLowerCase().equals("!exit")) {System.exit(0);}
						if (userA.equals("!flip")) {System.out.println(temp.flip());}
						else {
							loop2 = false;
							if (userA.toLowerCase().equals(awnser)|| userA == ""){
								temp.addToUpper();}
							else{temp.addTolower();}}}
					newcard = true;
					break;
				case 2:
					boolean loop3 = true;
					while (loop3) {
						System.out.println("Input Search :");
						String search = in.next();
						if (search.toLowerCase().equals("!exit")) {System.exit(0);}
						if (search.equals("!flip")) {System.out.println(temp.flip());}
						else {
							SearchFor(search);
							loop3 =false;}}
					break;
				case 3:
					System.out.println("Listing all cards :");
					ListAllCards();
					break;
				case 4:
					System.out.println("Printing all Boxes in order: ");
					allBoxes();
					break;
				case 5:
					simple();
				case 6:
					drill();
				case 7: 
					System.out.println("GoodBye");
					System.exit(0);}}}
	
	/**
	 * runs the simple study method for users		
	 * @throws IOException
	 */
	public static void simple() throws IOException {
		Scanner innn = new Scanner(System.in);
		boolean loop2 = true;
		
		System.out.println("You Entered The Simple Study method Is this correct (y/n)");
		String arg0= innn.next().toLowerCase();
		
		if (arg0.equals("n")) {App();}
		if (arg0.equals("!exit")) {System.exit(0);}
		
		System.out.println("So which box would you like to work on: ");
		
		int temp = innn.nextInt();
		
		if (simpleStudyBox(temp).isEmpty() == true) {
			System.out.println("Box"+temp +" is empty plese try another box");
			simple();}
		
		for(int tempint= simpleStudyBox(temp).getsize()-1; tempint > -1; tempint--) {
			Lsystem card = simpleStudyBox(temp).getItem(tempint);
			System.out.println(card.getQuestion());
			
			String awnser = card.getAwnser();
			System.out.println("Input Awnser: ");
			String userA = innn.next();				
			if (userA.toLowerCase().equals(awnser)|| userA == ""){
				card.addToUpper();}
			else{card.addTolower();}}
		App();}
	
	/**
	 * runs the drill study method for users
	 * @throws IOException
	 */
	public static void drill() throws IOException {
		Scanner inl = new Scanner(System.in);
		
		System.out.println("You Entered The Drill Study method Is this correct (y/n)");
		
		String arg0= inl.next().toLowerCase();
		if (arg0.equals("n") || arg0.equals("!back")) {App();}
		if (arg0.equals("!exit")) {System.exit(0);}
		
System.out.println("So which box would you like to work on: ");
		
		int temp = inl.nextInt();
		
		if (simpleStudyBox(temp).isEmpty() == true) {
			System.out.println("Box"+temp +" is empty plese try another box");
			drill();}
		
		List<Cards> templist = simpleStudyBox(temp).getlist();
		
		while (templist.size() >= 1) {
			Random rnum = new Random();
			int tempnum = rnum.nextInt(templist.size());
			
			Cards card = templist.get(tempnum);
			
			System.out.println("Qestion: " +card.getQuestion() + "\n Awnser: ");
			String anwser = card.getAwnser();
			
			String input = inl.next().toLowerCase();
			
			if (input.equals("!back")) {App();}
			if (input.equals("!exit")) {System.exit(0);}
			if (input.equals(anwser) || input == "") {
				templist.remove(tempnum);}}
		return;}
	}
