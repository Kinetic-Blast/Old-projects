import javax.swing.JFrame;

public class TetrominoTest {

	/**
	 * Java Tetromino Generator
	 * @author Baylee Byers
	 * @version 1.0 21 September 2018
	 */
	
	/**
	 * creates the frame and runs the paintComponent
	 */
	public static void main(String[] args) {
		JFrame frame = new JFrame("Tetris");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800, 800); //322,623
		
		Tetromino component = new Tetromino();
		
		frame.add(component);
		
		frame.setVisible(true);

}}
