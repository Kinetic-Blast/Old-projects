import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.Random;

import javax.swing.JComponent;

public class Tetromino extends JComponent {
	/**
	 * Java Tetromino Generator
	 * @author Baylee Byers
	 * @version 1.0 21 September 2018
	 */
	
	private static final long serialVersionUID = 1L;
	private int rpiece;
	private int defalt;
	
	private int x;
	private int y;
	private int c;
	
	/**
	 * creates a random number for the x values  of the shapes between 0 and 322
	 */
	public void RandomXrange() {
		if (x == c) {
		Random r =new Random();
		int temp = r.nextInt(323);
		x= temp;}
		return;}
	
	/**
	 * creates a random number for the y values of the shapes between 0 and 623
	 */
	public void RandomYrange() {
		if (y==c) {
		Random r = new Random();
		int temp = r.nextInt(624);
		y = temp;}
		return;}
	
	/**
	 * Generates a random number to select a Tetromino 
	 */
	public void RandomPiece() {
		if (rpiece == c) {
		Random r = new Random();
		int temp = r.nextInt(7);
		rpiece = temp;}
		return;}
	
	/**
	 * Generates a number between 1 and 4 to select the degree the shape will be in
	 * @return degree int that the Tetromino will be facing
	 */
	private double randomdegree() {
		if (defalt == c) {
			int degree = 0;
			Random r = new Random();
			int temp = r.nextInt(4);
		
			if (temp== 0) {degree = 0;}
			if (temp== 1) {degree = 90;}
			if (temp== 2) {degree = 180;}
			if (temp== 3) {degree = 270;}
			defalt = 1;
		return degree;}
		return 0;}
	
	/**
	 * Draws the piece that RandomPiece() selects as well as its postion via RandomXrange() and RandomYrange() in the direction that randomdegree() chooses
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D grd= (Graphics2D)g;
		RandomXrange();
		RandomYrange();
		RandomPiece();
		
		
		//square
		if (rpiece == 0) {
			Rectangle2D.Double square =new Rectangle2D.Double(x,y,50,50);
			grd.setPaint(Color.YELLOW);
			grd.fill(square);}
		
		//line
		if (rpiece == 1) {
			double temp = randomdegree();
			grd.rotate(Math.toRadians(temp),400,400);
			grd.setPaint(Color.CYAN);
			grd.fillRect(x,y, 25, 100);
			grd.rotate(-temp);}
		
		//reverse l
		if (rpiece == 2) {
			double temp = randomdegree();
			grd.rotate(Math.toRadians(temp),400,400);
			grd.setPaint(Color.ORANGE);
			grd.fillRect(x,y, 25, 75);
			grd.fillRect(x, y, 50, 25);
			grd.rotate(-temp);}
		
		// l shape 
		if (rpiece == 3) {
			double temp = randomdegree();
			grd.rotate(Math.toRadians(temp),400,400);
			grd.setPaint(Color.BLUE);
			grd.fillRect(x,y, 25, 75);
			grd.fillRect(x, y+50, 50, 25);
			grd.rotate(-temp);}
		
		//T shape
		if (rpiece == 4) {
			double temp = randomdegree();
			grd.rotate(Math.toRadians(temp),400,400);
			grd.setPaint(Color.MAGENTA);
			grd.fillRect(x,y, 25, 75);
			grd.fillRect(x, y+25, 50, 25);
			grd.rotate(-temp);}
		
		//z shape
		if (rpiece == 5) {
			double temp = randomdegree();
			grd.rotate(Math.toRadians(temp),400,400);
			grd.setPaint(Color.MAGENTA);
			grd.fillRect(x,y, 25, 50);
			grd.fillRect(x+25, y+25, 25, 50);
			grd.rotate(-temp);}
		
		//reverse z shape
		if (rpiece == 6) {
			double temp = randomdegree();
			grd.rotate(Math.toRadians(temp),400,400);
			grd.setPaint(Color.RED);
			grd.fillRect(x,y, 25, 50);
			grd.fillRect(x-25, y+25, 25, 50);
			grd.rotate(-temp);}}}