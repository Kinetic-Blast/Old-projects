

import java.util.NoSuchElementException;

public class MyLinkedList{
	private Node first;
	
	public MyLinkedList(){
		first = null;
	}
	
	public void addFirst(Object element){
		Node newNode = new Node();
		newNode.data = element;
		newNode.next = first;
		first = newNode;
	}
	
	public Object getFirst(){
		if(first == null){ throw new NoSuchElementException();}
		return first.data;
	}
	
	public Object removeFirst(){
		if(first == null){ throw new NoSuchElementException();}
		Object element = first.data;
		first = first.next;
		return element;
	}

	public ListIterator listIterator(){
		return new LinkedListIterator();
	}
	
	
	/*
	 * YOUR WORK HERE
	 */
	public class LinkedListIterator implements ListIterator {
		
		Node Prev;
		Node Curr;
		Node Next;
		boolean nextCalled;
		
		public LinkedListIterator(){}
		@Override
		public void add(Object arg0) {
			Node newNode = new Node();
			newNode.data = arg0;
			
			if(first == null) {
				first = newNode;}
			
			else if  (Curr == null ) {
				newNode.next = first;
				first = newNode;}
			
			else {
				newNode.next = Curr.next;
				Curr.next = newNode;
				Next = newNode;}}

		@Override
		public boolean hasNext() {
			return (Prev == null && first != null) || (Next != null);}

		@Override
		public Object next() {
			if(Curr == null) {
				Curr = first;
				Next = Curr.next;}
			else if (Next != null) {
				Prev = Curr;
				Curr = Next;
				Next = Curr.next;}
			
			nextCalled = true;
			return Curr.data;}

		@Override
		public void remove() {
			if (nextCalled) {
				Node removed = Curr;
				if (Prev == null) {
					Curr = Next;}
				else {
					Prev.next = Next;
					Curr = Prev;}
				
				if (removed == first) {
					first = first.next;}}}}}
