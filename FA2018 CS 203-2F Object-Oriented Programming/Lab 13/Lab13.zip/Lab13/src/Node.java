


public class Node {
	public Object data;
	public Node next;

}
