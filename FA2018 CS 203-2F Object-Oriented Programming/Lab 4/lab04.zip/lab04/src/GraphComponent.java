

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

/*
 * a component for drawing a graph
 */
public class GraphComponent extends JComponent{
	
	int x = 200;
	int y = 200;
	

	public void paintComponent(Graphics g){
		Graphics2D l= (Graphics2D)g;
		
		//The large Square
		l.draw(new Rectangle2D.Double(x, y,x+300,y+125));
		
		// Two Ovals
		l.draw(new Ellipse2D.Double(x+25,y+50,x,y-50));
		l.draw(new Ellipse2D.Double(x+275,y+50,x,y-50));
		
		//two colored Ovals
		Ellipse2D.Double r = new Ellipse2D.Double(x+75,y+50,x-100,y-50);
		Ellipse2D.Double o = new Ellipse2D.Double(x+325,y+50,x-100,y-50);
		l.setPaint(Color.CYAN);
		l.fill(r);
		l.fill(o);
		
		//the mouth
		//315 to 90 
		
		Arc2D.Double t = new Arc2D.Double(x+175,y+165,x-50,y-50,315,90,Arc2D.PIE);
		l.setPaint(Color.red);
		l.fill(t);
		
		//45 to 135
		
		Arc2D.Double f = new Arc2D.Double(x+175,y+165,x-50,y-50,45,90,Arc2D.PIE);
		l.setPaint(Color.yellow);
		l.fill(f);
		
		//135 to 225
		
		Arc2D.Double u = new Arc2D.Double(x+175,y+165,x-50,y-50,135,90,Arc2D.PIE);
		l.setPaint(Color.green);
		l.fill(u);
		
		//225 to 315
		Arc2D.Double q = new Arc2D.Double(x+175,y+165,x-50,y-50,225,90,Arc2D.PIE);
		l.setPaint(Color.blue);
		l.fill(q);
		l.setPaint(Color.black);
		
		// lines could not get them to line up
		l.draw(new Line2D.Double(x,y,x+250,y-150));
		l.draw(new Line2D.Double(x+500,y,x+25,y-150));
	}
	
	

	private static final long serialVersionUID = 1L;

}
